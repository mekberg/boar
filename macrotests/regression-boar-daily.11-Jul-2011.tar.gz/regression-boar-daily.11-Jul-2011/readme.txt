This folder contains a workdir and a repository created with boar
version "boar-daily.11-Jul-2011". For every revision, there is a md5
checksum file for the contents.

The following changes were made:

rev 1: The session "Test" is created.

rev 2: The files "some_text.txt" and "subdir/some_text.txt" are added.

rev 3, 4: The session property "ignore" is set to "*.tmp".

rev 5: the empty file "empty_file.txt" is created.

rev 6: The file "copy_of_some_text.txt" is created

rev 7: Aborted after commit but before queue processing. Deleted
"empty_file.txt", modified "some_text.txt", added "new_file.txt".
